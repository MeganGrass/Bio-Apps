BioHazard 2 Dual Shock
Remix CDX Archive Compiler

x64 OS
v0.0.0.0

---> ABOUT <---
Small utility to compile CDX archive files for a PSone video game mod project, located here:
http://www.the-horror.com/forums/showthread.php?10487-Bio2-Bio1-5-Mix


---> IMPORTANT <---
This is a commandline utility for 64-bit operating systems only (Win7+)


---> COMMAND <---
CDXBSS <DIRECTORY> <BGMTBL>	Create all BSS cdx files. BSS files must be located in the directory
example: bio2dsr cdxbss "C:\BSS Files" "C:\BSS Files\bgmtbl.txt"

CDXBSSEX <DIRECTORY> <BGMTBL>	Create BSS files using new LZ compression method for sprites.
example: bio2dsr cdxbssex "C:\BSS Files" "C:\BSS Files\bgmtbl.txt"

				Files must be named accordingly:
				ROOM10000.BS
				ROOM10000Spr.TIM
				ROOM10001.BS
				ROOM10001Spr.TIM
				...
				ROOM70000.BS
				ROOM70000Spr.TIM
				ROOM70001.BS
				ROOM70001Spr.TIM

CDXBGM <DIRECTORY>		Create SNDMAIN and SNDSUB cdx files
example: bio2dsr cdxbgm "C:\BGM Files"

CDXBGM <DIRECTORY>		Create DO2 cdx file
example: bio2dsr cdxdo2 "C:\DO2 Files"

CDXBGM <DIRECTORY>		Create PLD cdx file
example: bio2dsr cdxpld "C:\PLD Files"

CDXBGM <DIRECTORY> <PLDID>	Create PLW cdx file
example: bio2dsr cdxplw "C:\PLD Files" 0
example: bio2dsr cdxplw "C:\PLD Files" 0x0F

CDXBGM <DIRECTORY> <PLDID>	Create RDT cdx files
example: bio2dsr cdxrdt "C:\RDT Files" 0
example: bio2dsr cdxrdt "C:\RDT Files" 1
example: bio2dsr cdxrdt "C:\RDT Files" 0x00
example: bio2dsr cdxrdt "C:\RDT Files" 0x01

CDXBGM <DIRECTORY>		Create SNDARMS cdx file
example: bio2dsr cdxarms "C:\SND Files"

CDXBGM <DIRECTORY>		Create SNDCORE cdx file
example: bio2dsr cdxcore "C:\SND Files"

---> NOTES <---

The cdxbss commands require a BGM table list (default/vanilla listing included as bgmtbl.txt) because
the Bio2DS Remix project expanded the max amount of RDTs per Stage. Therefore, the memory card file,
init_tbl.dat doesn't include enough space for this listing. The BSS cdx files are the perfect place to
locate them, as their indices are only loaded once per stage. Failure to include the bgm table will
result in nullified BGM listings, thus no music will be played. The bgmtbl.txt is open for editing.

All commands, excluding CDXBSSEX, will search for default names of files - just as they appear on the
vanilla discs of Bio2/RE2 Dual Shock.